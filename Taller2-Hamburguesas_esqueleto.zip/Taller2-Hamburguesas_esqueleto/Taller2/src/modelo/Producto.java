package modelo;

public interface Producto {
	
	public  double getPrecio();
	
	public String getNombre();
	
	public String generarTextoFactura();

	public int getNo();

}
